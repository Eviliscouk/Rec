﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excelian.Maze;

namespace MazeWpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private MazeViewModel viewModel;
        public MainWindow()
        {
            InitializeComponent();

            // file should be passed in from gui!
            var file = @"C:\Users\James\Desktop\Excelian Test\Microsoft\C#\ExampleMaze.txt";
            
            var mazeLoader = new MazeTxtFileLoader(file);
            var maze = new Maze(mazeLoader);
            maze.Load();
            var explorer = new Explorer(maze);

            viewModel = new MazeWpf.MazeViewModel(maze, explorer);

            viewModel.PropertyChanged += (sender, e) =>
            {
                if (e.PropertyName == "CurrentLocation")
                    HighlightLocation(viewModel.CurrentLocation);
            };

            this.DataContext = viewModel;

            this.Loaded += (sender, e) => HighlightLocation(viewModel.CurrentLocation);
        }

        private void AdvanceBtn_Click(object sender, RoutedEventArgs e)
        {
            viewModel.Advance();
            HighlightLocation(viewModel.CurrentLocation);
        }

        private void TurnLeftBtn_Click(object sender, RoutedEventArgs e)
        {
            viewModel.TurnLeft();
        }

        private void TurnRightBtn_Click(object sender, RoutedEventArgs e)
        {
            viewModel.TurnRight();
        }

        private void AutoBtn_Click(object sender, RoutedEventArgs e)
        {
            viewModel.Auto();
            HighlightLocation(viewModel.CurrentLocation);
        }

        private void HighlightLocation(Maze.MazeLocation location)
        {
            if (MazeGrid.ItemsSource == null)
                return;

            var y = viewModel.Maze.Table.Rows.Count;
            foreach (var dataItem in MazeGrid.ItemsSource)
            {
                y--;
                var x = 0;

                foreach (var col in MazeGrid.Columns)
                {
                    var content = col.GetCellContent(dataItem);
                    if (content != null)
                    {
                        DataGridCell cell = content.Parent as DataGridCell;
                        if (location.X == x && location.Y == y)
                            cell.Background = new SolidColorBrush(Colors.Red);
                        else
                            cell.Background = new SolidColorBrush(Colors.White);
                    }
                    x++;
                }
            }
        }

        private void MazeGrid_Loaded(object sender, RoutedEventArgs e)
        {
            HighlightLocation(viewModel.CurrentLocation);
        }
    }
}
