﻿using Excelian.Maze;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MazeWpf
{
    public class MazeViewModel : ObservableObject
    {
        private Maze _maze;
        private Explorer _explorer;
        public DataView Maze {get { return _maze.GetMazeAsDataTable().DefaultView;}}
        public Heading CurrentHeading { get { return _explorer.CurrentHeading; } }
        public Maze.MazeLocation CurrentLocation { get { return _explorer.CurrentLocation; } }
        public List<string> Actions { get { return _explorer.GetActions().ToList(); } }
        
        public MazeViewModel(Maze maze,Explorer explorer)
        {
            _maze = maze;
            _explorer = explorer;
            OnPropertyChanged("Maze");
            OnPropertyChanged("CurrentHeading");
        }

        internal void Advance()
        {
            _explorer.Advance();
            OnPropertyChanged("CurrentLocation");
            OnPropertyChanged("Actions");
        }

        internal void TurnLeft()
        {
            _explorer.Turn(Direction.Left);
            OnPropertyChanged("CurrentHeading");
            OnPropertyChanged("Actions");
        }

        internal void TurnRight()
        {
            _explorer.Turn(Direction.Right);
            OnPropertyChanged("CurrentHeading");
            OnPropertyChanged("Actions");
        }

        internal void Auto()
        {
            _explorer.TraverseMaze();
            OnPropertyChanged("CurrentLocation");
            OnPropertyChanged("CurrentHeading");
            OnPropertyChanged("Actions");
        }
    }
}
