﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excelian.Maze;

namespace MazeApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var file = @"C:\Users\James Kerr\Desktop\Excelian Test\Microsoft\C#\ExampleMaze.txt";
            
            Console.WriteLine("Loading Maze from {0}", file);
            var mazeLoader = new MazeTxtFileLoader(file);
            var maze = new Maze(mazeLoader);

            if (maze.Load())
            {
                Console.WriteLine("Load Successful");
                Console.WriteLine("Maze has {0} Walls", maze.NoOfWalls);
                Console.WriteLine("Maze has {0} Empty Spaces", maze.NoOfSpaces);
                Console.WriteLine("Load Successful");
                var explorer = new Explorer(maze);
                Console.WriteLine("Explorer has entered the maze at Start Point: X:{0}, Y:{1} - with a heading of {2}", explorer.CurrentLocation.X, explorer.CurrentLocation.Y, explorer.CurrentHeading);

                var squareInFront = explorer.GetSquareInFront();
                if (squareInFront != null)
                    Console.WriteLine("Explorer is looking at {0} represented by {1}", squareInFront.GetDisplayName(), squareInFront.GetDisplayIcon());

                var leftSquare = explorer.GetSquareAlongside(Direction.Left);
                var rightSquare = explorer.GetSquareAlongside(Direction.Right);
                Console.WriteLine("Explorer has a {0} represented by {1} to his left", leftSquare.GetDisplayName(), leftSquare.GetDisplayIcon());
                Console.WriteLine("Explorer has a {0} represented by {1} to his right", rightSquare.GetDisplayName(), rightSquare.GetDisplayIcon());

                Console.WriteLine("Turning explorer right");
                explorer.Turn(Direction.Right);

                squareInFront = explorer.GetSquareInFront();
                if (squareInFront != null)
                    Console.WriteLine("Explorer is looking at {0} represented by {1}", squareInFront.GetDisplayName(), squareInFront.GetDisplayIcon());

                leftSquare = explorer.GetSquareAlongside(Direction.Left);
                rightSquare = explorer.GetSquareAlongside(Direction.Right);
                Console.WriteLine("Explorer has a {0} represented by {1} to his left", leftSquare.GetDisplayName(), leftSquare.GetDisplayIcon());
                Console.WriteLine("Explorer has a {0} represented by {1} to his right", rightSquare.GetDisplayName(), rightSquare.GetDisplayIcon());

                explorer.Advance();
                explorer.Advance();
                explorer.Advance();
                explorer.Advance();
                explorer.Advance();
                explorer.Advance();
                explorer.Advance();
                explorer.Advance();
                explorer.Turn(Direction.Right);
                explorer.Advance();

                foreach (var action in explorer.GetActions())
                    Console.WriteLine(action);                
            }
            else
            {
                Console.WriteLine("Load failed");
                Console.ReadKey();
            }
        }
    }
}
