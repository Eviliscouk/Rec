﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Excelian.Maze
{
    public class Maze
    {
        private IMazeObject[,] _layout;
        private readonly IMazeLoader _loader;
        private int _maximumX;
        private int _maximumY;

        public int NoOfWalls { get { return _layout.OfType<Wall>().Count(); } }
        public int NoOfSpaces { get { return _layout.OfType<EmptySpace>().Count(); } }
        public MazeLocation StartPointLocation { get { return _layout.OfType<StartPoint>().First().Location; } }
        public MazeLocation ExitLocation { get { return _layout.OfType<StartPoint>().First().Location; } }

        public Maze(IMazeLoader loader)
        {
            _loader = loader;
        }

        public bool Load()
        {
            var layout = _loader.Load();

            if (ValidateLayout(layout))
            {
                _layout = layout;

                // once loaded store the layout bounds for safety checking later
                _maximumX = _layout.GetLength(0);
                _maximumY = _layout.GetLength(1);

                

                return true;
            }

            return false;
        }

        public static bool ValidateLayout(IMazeObject[,] layout)
        {
            if (layout == null)
                return false;

            // Check rules on layout, could impliment a maze validation interface to impliment different rules
            if (layout.OfType<StartPoint>().Count() != 1)
                return false;

            if (layout.OfType<Exit>().Count() != 1)
                return false;

            if (!layout.OfType<Wall>().Any())
                return false;

            if (!layout.OfType<EmptySpace>().Any())
                return false;

            return true;
        }

        public string GetSquareType(MazeLocation location)
        {
            var square = GetSquare(location);
            return square == null ? "Invalid Square Location!" : square.GetDisplayName();
        }

        public IMazeObject GetSquare(MazeLocation location)
        {
            if (location.X > _maximumX || location.Y > _maximumY)
                return null;

            return _layout[location.X, location.Y];
        }

        public static MazeLocation GetNextLocation(MazeLocation currentLocation, Heading heading)
        {
            switch (heading)
            {
                case Heading.North:
                     return new MazeLocation(currentLocation.X, currentLocation.Y + 1);
                case Heading.East:
                    return new MazeLocation(currentLocation.X + 1, currentLocation.Y);
                case Heading.South:
                    return new MazeLocation(currentLocation.X, currentLocation.Y - 1);
                case Heading.West:
                    return new MazeLocation(currentLocation.X - 1, currentLocation.Y);
                default:
                    return null;
            }
        }

        public class MazeLocation
        {
            public int X { get; private set; }
            public int Y { get; private set; }

            public MazeLocation(int x, int y)
            {
                X = x;
                Y = y;
            }
        }

        public DataTable GetMazeAsDataTable()
        {
            var rows = new List<DataRow>();
            var dataTable = new DataTable();
            for (int j = 0; j < _layout.GetLength(1); j++)
                dataTable.Columns.Add(new DataColumn(j.ToString()));

            for (int y = 0; y < _layout.GetLength(1); y++)
            {
                var newRow = dataTable.NewRow();
                for (int x = 0; x < _layout.GetLength(0); x++)
                    newRow[x.ToString()] = _layout[x, y].GetDisplayIcon();
                rows.Add(newRow);
            }

            rows.Reverse();

            foreach (var row in rows)
                dataTable.Rows.Add(row);

            return dataTable;
        }
    }

    public class Wall : IMazeObject
    {
        public string GetDisplayName()
        {
            return "Wall";
        }

        public char GetDisplayIcon()
        {
            return 'X';
        }
    }

    public class EmptySpace : IMazeObject
    {
        public string GetDisplayName()
        {
            return "Empty Space";
        }

        public char GetDisplayIcon()
        {
            return ' ';
        }
    }

    public class StartPoint : IMazeObject
    {
        public readonly Maze.MazeLocation Location;

        public StartPoint(Maze.MazeLocation location)
        {
            Location = location;
        }

        public string GetDisplayName()
        {
            return "Start Point";
        }

        public char GetDisplayIcon()
        {
            return 'S';
        }
    }

    public class Exit : IMazeObject
    {
        public readonly Maze.MazeLocation Location;

        public Exit(Maze.MazeLocation location)
        {
            Location = location;
        }

        public string GetDisplayName()
        {
            return "Exit";
        }

        public char GetDisplayIcon()
        {
            return 'F';
        }
    }
}
