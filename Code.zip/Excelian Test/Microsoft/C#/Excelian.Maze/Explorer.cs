﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Excelian.Maze
{
    public class Explorer : IMazeExplorer
    {
        private Maze _maze;
        private Heading _currentHeading;
        private Maze.MazeLocation _currentLocation;
        private readonly SortedDictionary<int, Maze.MazeLocation> _path = new SortedDictionary<int, Maze.MazeLocation>();
        private readonly List<string> _actions = new List<string>();

        public Maze.MazeLocation CurrentLocation
        {
            get { return _currentLocation; }
            set { _currentLocation = value; _path.Add(_path.Count+1, value); _actions.Add(String.Format("Moved to square X:{0}, Y:{1}", value.X, value.Y)); }
        }

        public Heading CurrentHeading 
        {
            get { return _currentHeading; }
            set { _currentHeading = value; _actions.Add(String.Format("Now Facing {0}", value)); } 
        }

        public Explorer(Maze maze, Heading heading = Heading.North)
        {
            _maze = maze;
            CurrentLocation = maze.StartPointLocation;
            CurrentHeading = heading;
        }

        public bool Advance()
        {
            var newLocation = Maze.GetNextLocation(_currentLocation, _currentHeading);

            if (newLocation == null)
                return false;

            if (_maze.GetSquare(newLocation) is Wall)
                return false;

            CurrentLocation = newLocation;

            return true;
        }

        public void Turn(Direction direction)
        {
            _actions.Add(String.Format("Turned {0}", direction));
            CurrentHeading = Turn(direction, _currentHeading);
        }

        public static Heading Turn(Direction direction, Heading initialHeading)
        {
            switch (initialHeading)
            {
                case Heading.North:
                    return (direction == Direction.Left) ? Heading.West : Heading.East;
                case Heading.East:
                    return (direction == Direction.Left) ? Heading.North : Heading.South;
                case Heading.South:
                    return (direction == Direction.Left) ? Heading.East : Heading.West;
                case Heading.West:
                return (direction == Direction.Left) ? Heading.South : Heading.North;

                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        public IMazeObject GetSquareInFront()
        {
            var newLocation = GetLocationInFront();
            if (newLocation == null)
                return null;
            return _maze.GetSquare(newLocation);
        }

        public Maze.MazeLocation GetLocationInFront()
        {
            var newLocation = Maze.GetNextLocation(_currentLocation, _currentHeading);
            if (newLocation == null)
                return null;
            return newLocation;
        }

        public IMazeObject GetSquareAlongside(Direction direction)
        {
            var newLocation = GetLocationAlongside(direction);
            if (newLocation == null)
                return null;
            return _maze.GetSquare(newLocation);
        }

        public Maze.MazeLocation GetLocationAlongside(Direction direction)
        {
            var newLocation = Maze.GetNextLocation(_currentLocation, Turn(direction, _currentHeading));
            if (newLocation == null)
                return null;
            return newLocation;
        }

        public IEnumerable<Maze.MazeLocation> GetPath()
        {
            return _path.Values.ToList();
        }

        public IEnumerable<string> GetActions()
        {
            return _actions.ToList();
        }

        public void TraverseMaze()
        {
            Maze.MazeLocation exitPoint = null;
            while (exitPoint == null)
            {
                var squareInFront = GetSquareInFront();
                if (squareInFront is Exit)
                {
                    Advance();
                    exitPoint = CurrentLocation;
                }
                else if (squareInFront is EmptySpace)
                {
                    var locationInFront = GetLocationInFront();
                    if (this._path.Any(x => x.Value.X == locationInFront.X && x.Value.Y == locationInFront.Y))
                    {
                        // Couldnt move forward so check squares either side
                        var leftSquare = GetSquareAlongside(Direction.Left);
                        var leftLocation = GetLocationAlongside(Direction.Left);
                        var rightSquare = GetSquareAlongside(Direction.Right);
                        var rightLocation = GetLocationAlongside(Direction.Right);

                        if (!(leftSquare is Wall) && !(rightSquare is Wall))
                        {
                            // both squares are open space
                            //check if we have been to either one before
                            if (this._path.Any(x => x.Value.X == leftLocation.X && x.Value.Y == leftLocation.Y))
                                Turn(Direction.Left);
                            else
                                Turn(Direction.Right);
                        }
                        else if (!(leftSquare is Wall))
                        {
                            Turn(Direction.Left);
                        }
                        else if (!(rightSquare is Wall))
                        {
                            Turn(Direction.Right);
                        }
                        else
                        {
                            Advance();
                        }
                    }
                    else
                    {
                        Advance();
                    }
                }
                else
                {
                    var movedForward = Advance();
                    if (!movedForward)
                    {
                        // Couldnt move forward so check squares either side
                        var leftSquare = GetSquareAlongside(Direction.Left);
                        var leftLocation = GetLocationAlongside(Direction.Left);
                        var rightSquare = GetSquareAlongside(Direction.Right);
                        var rightLocation = GetLocationAlongside(Direction.Right);

                        if (!(leftSquare is Wall) && !(rightSquare is Wall))
                        {
                            // both squares are open space
                            //check if we have been to either one before
                            if (this._path.Any(x => x.Value.X == leftLocation.X && x.Value.Y == leftLocation.Y))
                                Turn(Direction.Left);
                            else
                                Turn(Direction.Right);
                        }
                        else if (!(leftSquare is Wall))
                            Turn(Direction.Left);
                        else
                            Turn(Direction.Right);
                    }
                }
            }
        }
    }
}
