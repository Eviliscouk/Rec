﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excelian.Maze
{
    public interface IMazeExplorer
    {
        bool Advance();
        void Turn(Direction direction);
        IMazeObject GetSquareInFront();
        IMazeObject GetSquareAlongside(Direction direction);
        IEnumerable<Maze.MazeLocation> GetPath();
        IEnumerable<string> GetActions();
    }

    public enum Direction
    {
        Left = 1,
        Right = 2
    }

    public enum Heading
    {
        North = 1,
        East = 2,
        South = 3,
        West = 4
    }
}
