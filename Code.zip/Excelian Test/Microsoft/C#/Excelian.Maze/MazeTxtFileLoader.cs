﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excelian.Maze
{
    public class MazeTxtFileLoader : IMazeLoader
    {
        private readonly string _filePath = string.Empty;
        private char _wallIdentifier;
        private char _emptySpaceIdentifier;
        private char _startPointIdentifier;
        private char _exitIdentifier;

        public MazeTxtFileLoader(string filePath, char wallIdentifier = 'X', char emptySpaceIdentifier = ' ', char startPointIdentifier = 'S', char exitIdentifier = 'F')
        {
            _filePath = filePath;
            _wallIdentifier = wallIdentifier;
            _emptySpaceIdentifier = emptySpaceIdentifier;
            _startPointIdentifier = startPointIdentifier;
            _exitIdentifier = exitIdentifier;
        }

        public IMazeObject[,] Load()
        {
            if (!File.Exists(_filePath))
                return null;

            // load txt file
            var lines = File.ReadLines(_filePath).Reverse().ToList();

            // size layout to the size defined in 
            var mazeLayout = new IMazeObject[lines.Max(x => x.Length), lines.Count];

            // pad lines to biggest input line to prevent any jagged declaration in input file
            lines = lines.Select(x => x.PadRight(mazeLayout.GetLength(0), ' ')).ToList();

            // Load layout from text description

            var y = 0;
            foreach (var line in lines)
            {
                var x = 0;
                foreach (var c in line)
                {
                    IMazeObject mazeItem;
                    if (c == _wallIdentifier)
                        mazeItem = new Wall();
                    else if (c == _emptySpaceIdentifier)
                        mazeItem = new EmptySpace();
                    else if (c == _startPointIdentifier)
                        mazeItem = new StartPoint(new Maze.MazeLocation(x,y));
                    else if (c == _exitIdentifier)
                        mazeItem = new Exit(new Maze.MazeLocation(x, y));
                    else if (c == _emptySpaceIdentifier)
                        mazeItem = new EmptySpace();
                    else
                        mazeItem = new Wall(); // Note - defaulting unknown square types to wall

                    mazeLayout[x, y] = mazeItem;

                    x++;
                }

                y++;
            }

            return mazeLayout;
        }
    }
}
