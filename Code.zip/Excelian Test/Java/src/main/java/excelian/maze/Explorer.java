package excelian.maze;

public class Explorer {

	private int[] movement;

	public void exploreMaze(Maze m) {

	}

	private void move() {

	}

	private void turn() {

	}

}
