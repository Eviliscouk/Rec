package excelian.maze;

public class Maze {
}
