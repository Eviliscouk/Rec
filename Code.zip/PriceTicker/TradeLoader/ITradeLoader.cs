﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace TradeLoader
{
    public interface ITradeLoader
    {
        bool Load(string path, string filename);
        DataTable LoadedTrades { get; }
        string FileExtension { get; }
    }
}
