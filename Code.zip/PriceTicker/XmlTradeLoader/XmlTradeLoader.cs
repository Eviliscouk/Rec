﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using TradeLoader;

namespace XmlTradeLoader
{
    public class XmlTradeLoader : ITradeLoader
    {
        public XmlTradeLoader()
        {
            FileExtension = ".xml";
        }

        public bool Load(string path, string filename)
        {
            var ds = new DataSet("dataset");
            ds.ReadXml(Path.Combine(path, filename));
            LoadedTrades = ds.Tables[0];
            return true;
        }

        public DataTable LoadedTrades { get; private set; }
        public string FileExtension { get; private set; }
    }
}
