﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using PriceTicker;

namespace TradeFeed
{
    public class TradeFeed
    {
        private string _csvPath = @"C:\Users\jkerr\Documents\Visual Studio 2010\Projects\PriceTicker\TradeFeed";
        private List<string> _fileNames = new List<string> { "trades1.csv", "trades2.txt" };
        private ConcurrentBag<Price>  _prices = new ConcurrentBag<Price>();

        private void LoadTradesCsv(string path)
        {
            Parallel.ForEach(_fileNames, currentFile =>
                {
                    var dt = CsvReader.GetDataTableFromCsv(path, currentFile, currentFile, true);
                    foreach (var price in from DataRow row in dt.Rows
                                          select new Price(int.Parse(row["Id"].ToString()),
                                                           double.Parse(row["PriceA"].ToString()),
                                                           double.Parse(row["PriceB"].ToString()),
                                                           double.Parse(row["PriceC"].ToString()),
                                                           row["PriceName"].ToString()))
                        _prices.Add(price);
                });
            var prices = _prices;
        }
    }
}
