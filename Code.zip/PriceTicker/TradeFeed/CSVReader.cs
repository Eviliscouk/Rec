﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;

namespace TradeFeed
{
    public static class CsvReader
    {
        public static DataTable GetDataTableFromCsv(string path, string fileName, string dataTableName, bool isFirstRowHeader)
        {
            try
            {
                var header = isFirstRowHeader ? "Yes" : "No";

                var sql = string.Format(@"SELECT * FROM [{0}]", fileName);

                using (var connection = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path +";Extended Properties=\"Text;HDR=" + header + "\""))
                    
                    using (var command = new OleDbCommand(sql, connection))
                        
                        using (var adapter = new OleDbDataAdapter(command))
                        {
                            var dataTable = new DataTable(dataTableName) {Locale = CultureInfo.CurrentCulture};

                            adapter.Fill(dataTable);

                            return dataTable;
                        }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error parsing csv file " + Environment.NewLine + ex.Message);
                return null;
            }
        }
    }
}
