﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using WpfApplication1;

namespace TestProject1
{
    [TestClass()]
    public class BliackSholsStrategyTest
    {
        private TestContext testContextInstance;
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        [TestMethod()]
        public void VerifyExemple1()
        {
            double stock = 50.0;
            double strike = 55.0;
            double timeToMaturity = 1;
            double deviation = 0.2;
            double interestRate = 0.09;

            PriceContext context = new PriceContext(stock, strike, timeToMaturity, deviation, interestRate);

            BliackSholsStrategy target = new BliackSholsStrategy();
            var result = target.GetCallPrice(context);

            Assert.AreEqual(3.8617410318488332, result);
        }

        [TestMethod()]
        public void VerifyExemple2()
        {
            double stock = 50.0;
            double strike = 55.0;
            double timeToMaturity = 1;
            double deviation = 0.2;
            double interestRate = 0.09;

            PriceContext context = new PriceContext(stock, strike, timeToMaturity, deviation, interestRate);

            BliackSholsStrategy target = new BliackSholsStrategy();
            var result = target.GetPutPrice(context);

            Assert.AreEqual(4.1279190013851519, result);
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ShouldThrowAnExpcetionIfPriceContextIsNullWhileCalculatingACall()
        {
            BliackSholsStrategy target = new BliackSholsStrategy();
            target.GetCallPrice(null);
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ShouldThrowAnExpcetionIfPriceContextIsNullWhileCalculatingAPut()
        {
            BliackSholsStrategy target = new BliackSholsStrategy();
            target.GetPutPrice(null);
        }
    }
}
