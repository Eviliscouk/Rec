﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using WpfApplication1;
using System.Globalization;

namespace TestProject1
{
    public enum TestEnum
    {
        opt1, opt2, opt3
    }

    [TestClass()]
    public class EnumBooleanConverterTest
    {
        private TestContext testContextInstance;
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        [TestMethod()]
        public void Convert_ShouldReturnFalseIfTheValuesAreDifferent()
        {
            EnumBooleanConverter converter = new EnumBooleanConverter();
            var result = converter.Convert(TestEnum.opt1, typeof(bool), "opt2", CultureInfo.InvariantCulture);
            Assert.IsTrue(result is bool);
            Assert.IsFalse((bool)result);
        }

        [TestMethod()]
        [ExpectedException(typeof(InvalidOperationException))]
        public void Convert_ShouldThrowAnExceptionIfObjectIsNull()
        {
            EnumBooleanConverter converter = new EnumBooleanConverter();
            var result = converter.Convert(null, typeof(bool), "opt2", CultureInfo.InvariantCulture);
        }

        [TestMethod()]
        [ExpectedException(typeof(InvalidOperationException))]
        public void Convert_ShouldThrowAnExceptionIfParameterIsNull()
        {
            EnumBooleanConverter converter = new EnumBooleanConverter();
            var result = converter.Convert(TestEnum.opt1, typeof(bool), null, CultureInfo.InvariantCulture);
        }

        [TestMethod()]
        public void Convert_ShouldReturnTrueIfTheValuesAreSame()
        {
            EnumBooleanConverter converter = new EnumBooleanConverter();
            var result = converter.Convert(TestEnum.opt1, typeof(bool), "opt1", CultureInfo.InvariantCulture);
            Assert.IsTrue(result is bool);
            Assert.IsTrue((bool)result);
        }

        [TestMethod()]
        public void ConvertBack_ShouldConvertToEnumIfValueIsDefined()
        {
            EnumBooleanConverter converter = new EnumBooleanConverter();
            var result = converter.ConvertBack(true, typeof(TestEnum), "opt2", CultureInfo.InvariantCulture);
            Assert.IsTrue(result is TestEnum);
            Assert.AreEqual(TestEnum.opt2, (TestEnum)result);
        }

        [TestMethod()]
        [ExpectedException(typeof(InvalidOperationException))]
        public void ConvertBack_ShouldThrowAnExceptionIfParameterIsNull()
        {
            EnumBooleanConverter converter = new EnumBooleanConverter();
            var result = converter.ConvertBack(true, typeof(TestEnum), null, CultureInfo.InvariantCulture);
            Assert.IsTrue(result is TestEnum);
            Assert.AreEqual(TestEnum.opt2, (TestEnum)result);
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentException))]
        public void ConvertBack_ShouldThrowAnExceptionIfValueIsNotDefined()
        {
            EnumBooleanConverter converter = new EnumBooleanConverter();
            var result = converter.ConvertBack(true, typeof(TestEnum), "NotDefinedValue", CultureInfo.InvariantCulture);
        }
    }
}
