﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using WpfApplication1;
using Moq;

namespace TestProject1
{
    [TestClass()]
    public class PriceEngineTest
    {
        private TestContext testContextInstance;
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ShouldThrowAnExpcetionIfStrategyIsNull()
        {
            PriceEngine engine = new PriceEngine(null);
        }

        [TestMethod()]
        public void ShouldShowtheStrategyNameAccordingToTheStrategyObjectType()
        {
            Mock<IPricingStrategy> strategyMock = new Mock<IPricingStrategy>();
            PriceEngine engine = new PriceEngine(strategyMock.Object);
            Assert.AreEqual(strategyMock.Object.GetType().Name, engine.StrategyName);
        }

        [TestMethod()]
        public void ShouldAskForACallProperly()
        {
            double resultValue = 1.1;
            PriceType type = PriceType.Call;
            Mock<IPricingStrategy> strategyMock = new Mock<IPricingStrategy>();
            strategyMock
                .Setup(x => x.GetCallPrice(It.IsAny<PriceContext>()))
                .Returns(resultValue)
                .Verifiable();
            strategyMock
                .Setup(x => x.GetPutPrice(It.IsAny<PriceContext>()))
                .Verifiable();

            PriceEngine engine = new PriceEngine(strategyMock.Object);
            var result = engine.CalculatePrice(PriceContext.Empty, type);

            Assert.AreEqual(resultValue, result.Value);
            Assert.AreEqual(type, result.PriceType);
            strategyMock.Verify(x => x.GetCallPrice(It.IsAny<PriceContext>()), Times.Once());
            strategyMock.Verify(x => x.GetPutPrice(It.IsAny<PriceContext>()), Times.Never());
        }

        [TestMethod()]
        public void ShouldAskForAPutProperly()
        {
            double resultValue = 1.1;
            PriceType type = PriceType.Put;
            Mock<IPricingStrategy> strategyMock = new Mock<IPricingStrategy>();
            strategyMock
                .Setup(x => x.GetPutPrice(It.IsAny<PriceContext>()))
                .Returns(resultValue)
                .Verifiable();
            strategyMock
                .Setup(x => x.GetCallPrice(It.IsAny<PriceContext>()))
                .Verifiable();

            PriceEngine engine = new PriceEngine(strategyMock.Object);
            var result = engine.CalculatePrice(PriceContext.Empty, type);

            Assert.AreEqual(resultValue, result.Value);
            Assert.AreEqual(type, result.PriceType);
            strategyMock.Verify(x => x.GetPutPrice(It.IsAny<PriceContext>()), Times.Once());
            strategyMock.Verify(x => x.GetCallPrice(It.IsAny<PriceContext>()), Times.Never());
        }
    }
}
