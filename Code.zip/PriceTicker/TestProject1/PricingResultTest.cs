﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using WpfApplication1;

namespace TestProject1
{
    [TestClass()]
    public class PricingResultTest
    {
        private TestContext testContextInstance;
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        [TestMethod()]
        public void ShouldExposeTheResultThorughTheValueProperty()
        {
            double value = 12.3;
            PricingResult result = new PricingResult(value, PriceType.Call);
            Assert.AreEqual(value, result.Value);
        }

        [TestMethod()]
        public void ShouldExposeTheResultThorughTheValuePropertyEvenWhenZero()
        {
            double value = 0;
            PricingResult result = new PricingResult(value, PriceType.Call);
            Assert.AreEqual(value, result.Value);
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ShouldThrowAnExcpetionWithNegativeResults()
        {
            double value = -7.9;
            PricingResult result = new PricingResult(value, PriceType.Call);
        }
    }
}
