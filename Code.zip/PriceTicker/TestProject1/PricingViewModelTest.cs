﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using WpfApplication1;
using Moq;

namespace TestProject1
{
    [TestClass()]
    public class PricingViewModelTest
    {
        private TestContext testContextInstance;
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ShouldThrowAnExceptionIfEngineIsNull()
        {
            PricingViewModel model = new PricingViewModel(null);
        }

        [TestMethod()]
        public void ShouldCallTheEngineToCalculateThePrice()
        {
            Mock<IPriceEngine> engineMock = new Mock<IPriceEngine>();
            double result = 12.1;
            engineMock
                .Setup(x => x.CalculatePrice(It.IsAny<PriceContext>(), PriceType.Call))
                .Returns(new PricingResult(result, PriceType.Call))
                .Verifiable();
            PricingViewModel model = new PricingViewModel(engineMock.Object);
            model.Calculate();
            Assert.AreEqual(result, model.Result);
            engineMock.Verify(x => x.CalculatePrice(It.IsAny<PriceContext>(), It.IsAny<PriceType>()), Times.Once());
        }

        #region ShouldNotCallTheEngineToCalculateThePriceWhenPricesAreNotValid

        [TestMethod()]
        public void ShouldNotCallTheEngineToCalculateThePriceWhenPricesAreNotValid_Stock()
        {
            ShouldNotCallTheEngineToCalculateThePriceWhenPricesAreNotValid(x => x.Stock = -12);
        }

        [TestMethod()]
        public void ShouldNotCallTheEngineToCalculateThePriceWhenPricesAreNotValid_Strike()
        {
            ShouldNotCallTheEngineToCalculateThePriceWhenPricesAreNotValid(x => x.Strike = -12);
        }

        [TestMethod()]
        public void ShouldNotCallTheEngineToCalculateThePriceWhenPricesAreNotValid_TimeToMaturity()
        {
            ShouldNotCallTheEngineToCalculateThePriceWhenPricesAreNotValid(x => x.TimeToMaturity = -12);
        }

        [TestMethod()]
        public void ShouldNotCallTheEngineToCalculateThePriceWhenPricesAreNotValid_InterestRate()
        {
            ShouldNotCallTheEngineToCalculateThePriceWhenPricesAreNotValid(x => x.InterestRate = 3);
        }

        [TestMethod()]
        public void ShouldNotCallTheEngineToCalculateThePriceWhenPricesAreNotValid_Deviation()
        {
            ShouldNotCallTheEngineToCalculateThePriceWhenPricesAreNotValid(x => x.Deviation = 3);
        }

        public void ShouldNotCallTheEngineToCalculateThePriceWhenPricesAreNotValid(Action<PricingViewModel> actionToMakeTheModelInvalid)
        {
            Mock<IPriceEngine> engineMock = new Mock<IPriceEngine>();
            engineMock
                .Setup(x => x.CalculatePrice(It.IsAny<PriceContext>(), PriceType.Call))
                .Verifiable();
            PricingViewModel model = new PricingViewModel(engineMock.Object);
            actionToMakeTheModelInvalid(model);
            model.Calculate();
            Assert.AreEqual(0, model.Result);
            engineMock.Verify(x => x.CalculatePrice(It.IsAny<PriceContext>(), It.IsAny<PriceType>()), Times.Never());
        }

        #endregion

        #region ShouldRaisePropertyChangedEventWhenChangingProperty

        [TestMethod()]
        public void ShouldRaisePropertyChangedEventWhenChangingProperty_Stock()
        {
            ShouldRaisePropertyChangedEventWhenChangingProperty(x => x.Stock = 123, "Stock");
        }

        [TestMethod()]
        public void ShouldRaisePropertyChangedEventWhenChangingProperty_Strike()
        {
            ShouldRaisePropertyChangedEventWhenChangingProperty(x => x.Strike = 123, "Strike");
        }

        [TestMethod()]
        public void ShouldRaisePropertyChangedEventWhenChangingProperty_TimeToMaturity()
        {
            ShouldRaisePropertyChangedEventWhenChangingProperty(x => x.TimeToMaturity = 123, "TimeToMaturity");
        }

        [TestMethod()]
        public void ShouldRaisePropertyChangedEventWhenChangingProperty_Deviation()
        {
            ShouldRaisePropertyChangedEventWhenChangingProperty(x => x.Deviation = 123, "Deviation");
        }

        [TestMethod()]
        public void ShouldRaisePropertyChangedEventWhenChangingProperty_InterestRate()
        {
            ShouldRaisePropertyChangedEventWhenChangingProperty(x => x.InterestRate = 123, "InterestRate");
        }

        [TestMethod()]
        public void ShouldRaisePropertyChangedEventWhenChangingProperty_CallOrPut()
        {
            ShouldRaisePropertyChangedEventWhenChangingProperty(x => x.CallOrPut = PriceType.Put, "CallOrPut");
        }

        [TestMethod()]
        public void ShouldRaisePropertyChangedEventWhenChangingProperty_Result()
        {
            ShouldRaisePropertyChangedEventWhenChangingProperty(x => x.Result = 123, "Result");
        }

        public void ShouldRaisePropertyChangedEventWhenChangingProperty(Action<PricingViewModel> actionToRaiseEnvent, string propertyName)
        {
            Mock<IPriceEngine> engineMock = new Mock<IPriceEngine>();
            PricingViewModel model = new PricingViewModel(engineMock.Object);
            bool eventRaised = false;
            model.PropertyChanged +=
                new System.ComponentModel.PropertyChangedEventHandler((sender, e) =>
                {
                    if (ReferenceEquals(sender, model) && e.PropertyName == propertyName)
                        eventRaised = true;
                });
            actionToRaiseEnvent(model);
            Assert.IsTrue(eventRaised);
        }

        #endregion

        [TestMethod()]
        public void ShouldShowTheEngineStrategyName()
        {
            Mock<IPriceEngine> engineMock = new Mock<IPriceEngine>();
            string strategyName = "some name";
            engineMock
                .SetupGet(x => x.StrategyName)
                .Returns(strategyName)
                .Verifiable();
            PricingViewModel model = new PricingViewModel(engineMock.Object);
            Assert.AreEqual(strategyName, model.Strategy);
            engineMock.VerifyGet(x => x.StrategyName, Times.Once());
        }
    }
}
