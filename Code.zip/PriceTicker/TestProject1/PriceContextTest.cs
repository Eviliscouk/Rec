﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using WpfApplication1;

namespace TestProject1
{
    [TestClass()]
    public class PriceContextTest
    {
        private TestContext testContextInstance;
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        [TestMethod()]
        public void ShouldExposeAllTheFIeldsProperly()
        {
            double stock = 1.1;
            double strike = 2.2;
            double timeToMaturity = 3.3;
            double deviation = 0.1;
            double interestRate = 0.2;

            PriceContext context = new PriceContext(stock, strike, timeToMaturity, deviation, interestRate);

            Assert.AreEqual(stock, context.Stock);
            Assert.AreEqual(strike, context.Strike);
            Assert.AreEqual(timeToMaturity, context.TimeToMaturity);
            Assert.AreEqual(deviation, context.Deviation);
            Assert.AreEqual(interestRate, context.InterestRate);
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ShouldThrowAnExceptionIfStockLessThanZero()
        {
            double stock = -1.1;
            double strike = 2.2;
            double timeToMaturity = 3.3;
            double deviation = 0.1;
            double interestRate = 0.2;

            PriceContext context = new PriceContext(stock, strike, timeToMaturity, deviation, interestRate);
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ShouldThrowAnExceptionIfStrikeLessThanZero()
        {
            double stock = 1.1;
            double strike = -2.2;
            double timeToMaturity = 3.3;
            double deviation = 0.1;
            double interestRate = 0.2;

            PriceContext context = new PriceContext(stock, strike, timeToMaturity, deviation, interestRate);
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ShouldThrowAnExceptionIfExpirationLessThanZero()
        {
            double stock = 1.1;
            double strike = 2.2;
            double timeToMaturity = -3.3;
            double deviation = 0.1;
            double interestRate = 0.2;

            PriceContext context = new PriceContext(stock, strike, timeToMaturity, deviation, interestRate);
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ShouldThrowAnExceptionIfDeviationLessThanZero()
        {
            double stock = 1.1;
            double strike = 2.2;
            double timeToMaturity = 3.3;
            double deviation = -0.1;
            double interestRate = 0.2;

            PriceContext context = new PriceContext(stock, strike, timeToMaturity, deviation, interestRate);
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ShouldThrowAnExceptionIfInterestsLessThanZero()
        {
            double stock = 1.1;
            double strike = 2.2;
            double timeToMaturity = 3.3;
            double deviation = 0.1;
            double interestRate = -0.2;

            PriceContext context = new PriceContext(stock, strike, timeToMaturity, deviation, interestRate);
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ShouldThrowAnExceptionIfDeviationGreaterThanOne()
        {
            double stock = 1.1;
            double strike = 2.2;
            double timeToMaturity = 3.3;
            double deviation = 66.1;
            double interestRate = 0.2;

            PriceContext context = new PriceContext(stock, strike, timeToMaturity, deviation, interestRate);
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ShouldThrowAnExceptionIfInterestsGreaterThanOne()
        {
            double stock = 1.1;
            double strike = 2.2;
            double timeToMaturity = 3.3;
            double deviation = 0.1;
            double interestRate = 77.2;

            PriceContext context = new PriceContext(stock, strike, timeToMaturity, deviation, interestRate);
        }
    }
}
