﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using WpfApplication1;
using WpfApplication1.Validation;
using System.Globalization;

namespace TestProject1
{
    [TestClass()]
    public class IntegerValidationRuleTest
    {
        private TestContext testContextInstance;
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        [TestMethod()]
        public void ShouldReturnTrueIfValidationPass()
        {
            IntegerValidationRule rule = new IntegerValidationRule(0, 10);
            var result = rule.Validate(5, CultureInfo.InvariantCulture);
            Assert.IsTrue(result.IsValid);
            Assert.IsNull(result.ErrorContent);
        }

        [TestMethod()]
        public void ShouldReturnFalseIfGreaterThanTheUpperBound()
        {
            IntegerValidationRule rule = new IntegerValidationRule(0, 10);
            var result = rule.Validate(99, CultureInfo.InvariantCulture);
            Assert.IsFalse(result.IsValid);
            Assert.AreEqual("Please enter a number greater than 0 and less than 10", result.ErrorContent);
        }

        [TestMethod()]
        public void ShouldReturnFalseIfLessThanTheLowerBound()
        {
            IntegerValidationRule rule = new IntegerValidationRule(5);
            var result = rule.Validate(2, CultureInfo.InvariantCulture);
            Assert.IsFalse(result.IsValid);
            Assert.AreEqual("Please enter a number greater than 5", result.ErrorContent);
        }

        [TestMethod()]
        public void ShouldReturnFalseIfValueIsNotConvertible()
        {
            IntegerValidationRule rule = new IntegerValidationRule(5);
            var result = rule.Validate("not a number", CultureInfo.InvariantCulture);
            Assert.IsFalse(result.IsValid);
            Assert.AreEqual("Value is not a valid integer", result.ErrorContent);
        }
    }
}
