﻿using System.Collections.Concurrent;
using System.Linq;
using System.Threading;
using Moq;
using NUnit.Framework;

namespace PriceTicker.Tests
{
    [TestFixture]
    public class PriceTickerViewModelTests
    {
        [Test]
        public void Prices_ForEmptyDataFeed_ExpectEmptyPricesList()
        {
            var tradeFeed = new Mock<ITradeFeed>();
            tradeFeed.Setup(f => f.InitialPrices).Returns(new ConcurrentBag<Trade>());
            var priceTickerVm = new PriceTickerViewModel(tradeFeed.Object);
            Assert.AreEqual(0, priceTickerVm.Prices.Count);
        }       

        //then test what happens when you return full bag from tradefeed or when you fire events etc

        [Test]
        public void Prices_OnUpdatePriceFired_ExpectTradePricesUpdated()
        {
            var tradeFeed = new Mock<ITradeFeed>();
            
            tradeFeed.Setup(f => f.InitialPrices).Returns(new ConcurrentBag<Trade>() { new Trade(1, 1, 1, 1, "test")});
            var priceTickerVm = new PriceTickerViewModel(tradeFeed.Object);

            var waitHandle = new AutoResetEvent(false); //use autoreset event to wait for collection 

            // Wire to the collectionchanged event to wait for the trede feed thread to add the initial price items
            priceTickerVm.Prices.CollectionChanged += (sender, e) => 
                {
                    //raise an event through mock
                    tradeFeed.Raise(t => t.UpdatePrice += null, null, new Trade(1, 2, 2, 2, "test"));
                    waitHandle.Set();
                };

            waitHandle.WaitOne();

            // Check for matching price
            var result = priceTickerVm.Prices.FirstOrDefault();
            if (result == null) Assert.Fail("No prices in collection!");
            Assert.AreEqual(2, result.PriceA);
            Assert.AreEqual(2, result.PriceB);
            Assert.AreEqual(2, result.PriceC);
        }       

    }
}
