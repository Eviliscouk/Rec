﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using TradeLoader;

namespace CsvTradeLoader
{
    public class CsvTradeLoader : ITradeLoader
    {
        public CsvTradeLoader()
        {
            FileExtension = ".csv";
        }

        public bool Load(string path, string filename)
        {
            try
            {
                LoadedTrades = CsvReader.GetDataTableFromCsv(path, filename, filename, ",");
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public DataTable LoadedTrades { get; private set; }
        public string FileExtension { get; private set; }
    }
}
