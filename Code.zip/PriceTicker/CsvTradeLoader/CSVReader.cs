﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using Microsoft.VisualBasic.FileIO;

namespace CsvTradeLoader
{
    public static class CsvReader
    {
        public static DataTable GetDataTableFromCsv(string path, string fileName, string dataTableName, string delimiter)
        {
            try
            {
                var dt = new DataTable(dataTableName);
                using (var parser = new TextFieldParser(Path.Combine(path, fileName)) { TextFieldType = FieldType.Delimited, Delimiters = new[] {delimiter}})
                {
                    var headers = parser.ReadFields();
                    if (headers == null) return dt;
                    foreach (var header in headers)
                        dt.Columns.Add(header);
                    
                    while (!parser.EndOfData)
                    {
                        var newRow = dt.NewRow();
                        var fields = parser.ReadFields();
                        if (fields == null) return dt;
                        
                        for (var i = 0; i < fields.Length; i++)
                            newRow[i] = fields[i];
                        
                        dt.Rows.Add(newRow);
                    }
                }
                return dt;

                /*
                var header = isFirstRowHeader ? "Yes" : "No";

                var sql = string.Format(@"SELECT * FROM [{0}]", fileName);

                using (var connection = new OleDbConnection(@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path +";Extended Properties=\"Text;HDR=" + header + "\""))
                    
                    using (var command = new OleDbCommand(sql, connection))
                        
                        using (var adapter = new OleDbDataAdapter(command))
                        {
                            var dataTable = new DataTable(dataTableName) {Locale = CultureInfo.CurrentCulture};

                            adapter.Fill(dataTable);

                            return dataTable;
                        }
                 * */
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error parsing csv file " + Environment.NewLine + ex.Message);
                return null;
            }
        }
    }
}
