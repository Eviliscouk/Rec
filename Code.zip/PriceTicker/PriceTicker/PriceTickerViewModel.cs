﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Threading;

namespace PriceTicker
{
    public class PriceTickerViewModel : ObservableObject
    {
        public  ObservableCollection<Trade> Prices { get; private set;}
        private Task _tradeFeedTask;
        private RelayCommand _startPriceFeed;
        private RelayCommand _pausePriceFeed;
        private ITradeFeed _tradeFeed;

        public PriceTickerViewModel(ITradeFeed tradeFeed)
        {
            // Trade feed will be dealt with on a seperate thread
            _tradeFeed = tradeFeed;
            // Price collection for view
            Prices = new ObservableCollection<Trade>();
            // Start a new thread for trade feed
            _tradeFeedTask = Task.Factory.StartNew(InitTradeFeed, TaskCreationOptions.LongRunning);
        }

        private void AddPrice(Trade newTrade)
        {
            // Add new price item to collection from UI thread only!
            Dispatcher.CurrentDispatcher.Invoke(new Action(() => Prices.Add(newTrade)));
        }

        private void UpdatePrice(Trade updatedTrade)
        {
            // Update price item to collection from UI thread only!
            Dispatcher.CurrentDispatcher.Invoke(new Action(() =>
                {
                    var price = Prices.FirstOrDefault(p => p.Id == updatedTrade.Id);
                    if (price != null)
                    {
                        price.PriceA = updatedTrade.PriceA;
                        price.PriceB = updatedTrade.PriceB;
                        price.PriceC = updatedTrade.PriceC; 
                        price.PriceName = updatedTrade.PriceName;
                    }
                }
                ));
        }

        private void InitTradeFeed()
        {
            // Wire up to recieve price updates from trade feed.
            _tradeFeed.UpdatePrice += (sender, e) => UpdatePrice(e);

            // Add initial price items loaded into trade feed to price collection
            foreach (var initialPrice in _tradeFeed.InitialPrices)
                AddPrice(initialPrice);
        }

        private void StartTradeFeed()
        {
            // Ask Trade feed to run!
            _tradeFeedTask.ContinueWith(delegate { _tradeFeed.StartFeed(); }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void PauseTradeFeed()
        {
            // Ask Trade feed to pause!
            _tradeFeedTask.ContinueWith(delegate { _tradeFeed.PauseFeed(); }, TaskScheduler.FromCurrentSynchronizationContext());
        }

        public ICommand StartPriceFeedCommand
        {
            get
            {
                if (_startPriceFeed != null) return _startPriceFeed;

                _startPriceFeed = new RelayCommand(p => StartTradeFeed(), p => true);
                return _startPriceFeed;
            }
        }

        public ICommand PausePriceFeedCommand
        {
            get
            {
                if (_pausePriceFeed != null) return _pausePriceFeed;

                _pausePriceFeed = new RelayCommand(p => PauseTradeFeed(), p => true);
                return _pausePriceFeed;
            }
        }
    }
}
