﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PriceTicker
{
    public class ViewModelLocator
    {
        public static PriceTickerViewModel PriceTickerViewModel
        {
            get { return new PriceTickerViewModel(new TradeFeed()); }
        }
    }
}
