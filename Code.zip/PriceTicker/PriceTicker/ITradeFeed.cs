﻿using System.Collections.Concurrent;

namespace PriceTicker
{
    public interface ITradeFeed
    {
        ConcurrentBag<Trade> InitialPrices { get; }
        void StartFeed();
        void PauseFeed();
        event TradeFeed.NewPriceEventHandler UpdatePrice;
    }
}