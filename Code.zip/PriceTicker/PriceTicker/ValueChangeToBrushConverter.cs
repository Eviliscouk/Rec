﻿using System;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace PriceTicker
{
    class ValueChangeToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            //Return a brush to paint the cell background
            var fromCol = Colors.Transparent;
            Color toCol;
            var brush = new SolidColorBrush(fromCol);

            var input = (Trade.ValueChange)value;
            switch (input)
            {
                case Trade.ValueChange.None:
                    return brush;
                case Trade.ValueChange.Increase:
                    {
                        toCol = Colors.LawnGreen;
                        break;
                    }
                case Trade.ValueChange.Decrease:
                    {
                        toCol = Colors.Red;
                        break;
                    }
                default:
                    return DependencyProperty.UnsetValue;
            }

            // If it is a positive or negative change add an an animation to the brush to highlight the cell background
            var ani = new ColorAnimationUsingKeyFrames {AutoReverse = true, RepeatBehavior = new RepeatBehavior(1)};
            var f1 = new LinearColorKeyFrame(fromCol) {KeyTime = KeyTime.FromTimeSpan(new TimeSpan(0, 0, 0, 0, 50))};
            var f2 = new EasingColorKeyFrame(toCol) {KeyTime = KeyTime.FromTimeSpan(new TimeSpan(0, 0, 0, 0, 500))};
            ani.KeyFrames.Add(f1);
            ani.KeyFrames.Add(f2);

            // Kick of Animation
            brush.BeginAnimation(SolidColorBrush.ColorProperty, ani);
            return brush;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
