﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PriceTicker
{
    public class Trade : ObservableObject
    {
        private int _id;
        private string _priceName;
        private double _priceA;
        private object _priceALock = new object();
        private double _priceB;
        private object _priceBLock = new object();
        private double _priceC;
        private object _priceCLock = new object();
        private ValueChange _valueChangedA;
        private ValueChange _valueChangedB;
        private ValueChange _valueChangedC;

        public int    Id        { get { return _id; }           set { _id = value;          OnPropertyChanged("Id"); } }
        public string PriceName { get { return _priceName; }    set { _priceName = value;   OnPropertyChanged("PriceName"); } }

        public double PriceA 
        { 
            get { lock(_priceALock) return _priceA; } 
            set
            {
                lock (_priceALock)
                {
                    ValueChangedA = CheckValueChange(_priceA, value);
                    _priceA = value;
                }
                OnPropertyChanged("PriceA");
            } 
        }

        public double PriceB
        {
            get { lock (_priceBLock) return _priceB; }
            set
            {
                lock (_priceBLock)
                {
                    ValueChangedB = CheckValueChange(_priceB, value);
                    _priceB = value;
                }
                OnPropertyChanged("PriceB");
            }
        }

        public double PriceC
        {
            get { lock (_priceCLock) return _priceC; } 
            set
            {
                lock (_priceCLock)
                {
                    ValueChangedC = CheckValueChange(_priceC, value);
                    _priceC = value;
                }
                OnPropertyChanged("PriceC");
            }
        }

        public ValueChange ValueChangedA
        {
            get { return _valueChangedA; }
            set { _valueChangedA = value; OnPropertyChanged("ValueChangedA"); }
        }
        public ValueChange ValueChangedB
        {
            get { return _valueChangedB; }
            set { _valueChangedB = value; OnPropertyChanged("ValueChangedB"); }
        }
        public ValueChange ValueChangedC
        {
            get { return _valueChangedC; }
            set { _valueChangedC = value; OnPropertyChanged("ValueChangedC"); }
        }


        public Trade(int id, double priceA, double priceB, double priceC, string name)
        {
            _id = id;
            _priceA = priceA;
            _priceB = priceB;
            _priceC = priceC;
            _priceName = name;
            _valueChangedA = ValueChange.None;
        }

        private static ValueChange CheckValueChange(double current, double next)
        {
            if (next > current) return ValueChange.Increase;
            if (next < current) return ValueChange.Decrease;
            return ValueChange.None;
        }

        public enum ValueChange
        {
            None = 0,
            Increase = 1,
            Decrease = 2
        }
    }
}
