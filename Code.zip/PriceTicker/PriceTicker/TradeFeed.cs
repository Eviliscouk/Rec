﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Collections.Concurrent;
using System.Timers;
using TradeLoader;

namespace PriceTicker
{
    public class TradeFeed : ITradeFeed
    {
        private string _inputFilePath = Environment.CurrentDirectory;
        private ConcurrentDictionary<string, ITradeLoader> _loaders =new ConcurrentDictionary<string, ITradeLoader>();
        private ConcurrentBag<string> _inputs = new ConcurrentBag<string>(); 
        private ConcurrentBag<Trade>  _prices = new ConcurrentBag<Trade>();
        Timer _timer = new Timer();
        private int _ticks;
        static Random _rnd1 = new Random();
        private List<string> _operators = new List<string> { "ADD", "SUBTRACT", "MULTIPLY", "NOTHING" }; 

        public delegate void NewPriceEventHandler(object sender, Trade p);
        public event NewPriceEventHandler UpdatePrice;

        public TradeFeed()
        {
            _timer =  new Timer {Interval = 1000};
            _timer.Elapsed += Tick;

            var stopwatch = new Stopwatch();
            stopwatch.Start();

            var types = GetAssignableTypes(typeof(ITradeLoader));
          
            foreach (var instance in CreateTradeLoaders(types))
                _loaders[instance.FileExtension] = instance;

            stopwatch.Stop();

            // temp load of input data would need to read this from somewhere and validate we have a loader to handle extension 
            var csvFullpath = Path.Combine(_inputFilePath, "trades1.csv");
            _inputs.Add(csvFullpath);
            var xmlFullpath = Path.Combine(_inputFilePath, "trades2.xml");
            _inputs.Add(xmlFullpath);

            Runloaders();
        }

        private static IEnumerable<ITradeLoader> CreateTradeLoaders(IEnumerable<Type> types)
        {
            return types.AsParallel().Select(t => (ITradeLoader)Activator.CreateInstance(t));
        }

        public ConcurrentBag<Trade>InitialPrices
        {
            get { return _prices; }
        }

        public void StartFeed()
        {
            _timer.Start();
        }

        public void PauseFeed()
        {
            _timer.Stop();
        }

        private static IEnumerable<Type> GetAssignableTypes(Type t)
        {
            var assemblies = LoadPlugInAssemblies();
            return assemblies.AsParallel().SelectMany(s => s.GetTypes()).Where(p => t.IsAssignableFrom(p) && p.IsClass).ToList();
        }

        private static IEnumerable<Assembly> LoadPlugInAssemblies()
        {
            var dInfo = new DirectoryInfo(Path.Combine(Environment.CurrentDirectory, "Plugins"));
            var files = dInfo.GetFiles("*.dll");
            return files.AsParallel().Select(file => Assembly.LoadFile(file.FullName)).ToList();
        }

        private void Runloaders()
        {
            Parallel.ForEach(_inputs, input =>
                {
                    var extension = Path.GetExtension(input);
                    if (extension == null) return;
                    
                    ITradeLoader loader;
                    if (!_loaders.TryGetValue(extension, out loader)) return;

                    if (!loader.Load(Path.GetDirectoryName(input), Path.GetFileName(input))) return;
                    
                    var datatable = loader.LoadedTrades;
                    foreach (DataRow row in datatable.Rows)
                    {
                        _prices.Add(new Trade(int.Parse(row["Id"].ToString()),
                                              double.Parse(row["PriceA"].ToString()),
                                              double.Parse(row["PriceB"].ToString()),
                                              double.Parse(row["PriceC"].ToString()),
                                              row["Name"].ToString()));
                    }
                });
        }

        private void Tick(object sender, ElapsedEventArgs e)
        {
            var results = new List<double>();

            for (var i = 0; i < 4; i++)
            {
                double result = 0;

                switch (_operators[_rnd1.Next(_operators.Count)])
                {
                    case "ADD":
                        result = 10.4 + _ticks;
                        break;
                    case "SUBTRACT":
                        result = _ticks - 3.6;
                        break;
                    case "MULTIPLY":
                        result = _ticks*2.6;
                        break;
                    case "NOTHING":
                        result = 0;
                        break;
                    default:
                        break;
                }
                results.Add(result);
            }

            UpdatePrice(this, new Trade(1, results[_rnd1.Next(results.Count)], results[_rnd1.Next(results.Count)], results[_rnd1.Next(results.Count)], "ChangedName1_" + _ticks));
            UpdatePrice(this, new Trade(2, results[_rnd1.Next(results.Count)], results[_rnd1.Next(results.Count)], results[_rnd1.Next(results.Count)], "ChangedName2_" + _ticks));
            UpdatePrice(this, new Trade(3, results[_rnd1.Next(results.Count)], results[_rnd1.Next(results.Count)], results[_rnd1.Next(results.Count)], "ChangedName3_" + _ticks));
            UpdatePrice(this, new Trade(4, results[_rnd1.Next(results.Count)], results[_rnd1.Next(results.Count)], results[_rnd1.Next(results.Count)], "ChangedName4_" + _ticks));
            UpdatePrice(this, new Trade(5, results[_rnd1.Next(results.Count)], results[_rnd1.Next(results.Count)], results[_rnd1.Next(results.Count)], "ChangedName5_" + _ticks));
            UpdatePrice(this, new Trade(6, results[_rnd1.Next(results.Count)], results[_rnd1.Next(results.Count)], results[_rnd1.Next(results.Count)], "ChangedName6_" + _ticks));

            _ticks++;
        }
    }
}
